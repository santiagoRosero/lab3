package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Panel_Options extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String UPLOAD = "upload";
	public static final String ADD = "add";
	public static final String DELETE = "delete";
	public static final String SEARCH = "search";
	public static final String REBOOT = "update";
	public static final String GRAPHICS = "graphics";
	public static final String MAYOR = "mayor";
	public static final String MENOR = "menor";
	
	
	private JButton btn_Upload;
	private JButton btn_add;
	private JButton btn_delete;
	private JButton btn_search;
	private JButton btn_reboot;
	private JButton btn_graphics;
	private JButton btn_mayor;
	private JButton btn_menor;
	
	
	private JTextField txt;
	
	
	private Main_Interfaz main;


	public Panel_Options(Main_Interfaz main){
		this.main = main;
		
		txt  = new JTextField();
		
		btn_Upload = new JButton("UPLOAD");
		btn_Upload.addActionListener(this);
		btn_Upload.setActionCommand(UPLOAD);
		
		btn_add = new JButton("ADD");
		btn_add.addActionListener(this);
		btn_add.setActionCommand(ADD);
		
		btn_delete = new JButton("DELETE");
		btn_delete.addActionListener(this);
		btn_delete.setActionCommand(DELETE);
		
		btn_search = new JButton("SEARCH");
		btn_search.addActionListener(this);
		btn_search.setActionCommand(SEARCH);
		
		btn_reboot  = new JButton("REBOOT");
		btn_reboot.addActionListener(this);
		btn_reboot.setActionCommand(REBOOT);
		
		btn_graphics = new JButton("GRAPHICS");
		btn_graphics.addActionListener(this);
		btn_graphics.setActionCommand(GRAPHICS);
		
		btn_mayor = new JButton("MAYOR");
		btn_mayor.addActionListener(this);
		btn_mayor.setActionCommand(MAYOR);
		
		btn_menor = new JButton("MENOR");
		btn_menor.addActionListener(this);
		btn_menor.setActionCommand(MENOR);
		
		setLayout(new GridLayout(4, 1,0,20));
		
		JPanel aux = new JPanel();
		aux.setLayout(new GridLayout(3, 1,0,5));
		aux.add(btn_add);
		aux.add(btn_delete);
		aux.add(btn_search);
		
		JPanel aux1 = new JPanel();
		aux1.setLayout(new GridLayout(3, 1,0,5));
		aux1.add(btn_graphics);
		aux1.add(btn_mayor);
		aux1.add(btn_menor);
		
		JPanel aux2 = new JPanel();
		aux2.setLayout(new GridLayout(3, 1,0,5));
		
		aux2.add(txt);
		aux2.add(btn_Upload);
		aux2.add(btn_reboot);
		
		aux.setBorder( new CompoundBorder(new EmptyBorder( 4, 3, 3, 3 ), new TitledBorder( "Options" ) ) );
		aux1.setBorder( new CompoundBorder(new EmptyBorder( 4, 3, 3, 3 ), new TitledBorder( "Actions" ) ) );
		aux2.setBorder( new CompoundBorder(new EmptyBorder( 4, 3, 3, 3 ), new TitledBorder( "Uploads" ) ) );
		
		ImageIcon img = new ImageIcon("data/BVC.png");
		
		JPanel im = new JPanel();
		im.setLayout(new BorderLayout());
		
		JLabel lb = new JLabel(img);
		
		lb.setBounds(100,100,100,100);
		im.add(lb, BorderLayout.SOUTH);
		
		im.setBackground(Color.WHITE);
		aux.setBackground(Color.WHITE);
		aux1.setBackground(Color.WHITE);
		aux2.setBackground(Color.WHITE);
		setBackground(Color.WHITE);
		
		
		add(im);
		add(aux2);
		add(aux1);
		add(aux);
		
	}

	public void setTxt(String text) {
		this.txt.setText(text);
	}


	@Override
	public void actionPerformed(ActionEvent event) {
		
		String  command = event.getActionCommand();
		
		if(command.equals(UPLOAD)){
			main.uploadData();
		}
		
		else if(command.equals(ADD)){
			main.addAccions();
		}
		

		else if(command.equals(DELETE)){
			main.delete();
		}

		else if(command.equals(SEARCH)){
			String dlt = JOptionPane.showInputDialog("Search per options " + "\n" + " 1. time mayor crecimiento \n 2. superan el valor rango \n 3. divisas mayor crecimiento");
			main.searchAccions(dlt);
		}
		

		else if(command.equals(REBOOT)){
			main.reboot();
		}
		

		else if(command.equals(GRAPHICS)){
			main.graphicsAccions();
		}
		

		else if(command.equals(MAYOR)){
			main.mayorAcion();
		}
		

		else if(command.equals(MENOR)){
			main.menorAccions();
		}
		
		
	}
	
	
	
	
	
	
	
	
	

}
