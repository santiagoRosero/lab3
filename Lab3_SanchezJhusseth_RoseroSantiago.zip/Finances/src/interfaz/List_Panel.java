package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import model.Accion;

public class List_Panel extends JPanel implements ListSelectionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
	private Main_Interfaz main;
	
	@SuppressWarnings("rawtypes")
	private JList listAccions;
	
	@SuppressWarnings("rawtypes")
	public List_Panel (Main_Interfaz main){
		
		this.main = main;
		

		setLayout(new BorderLayout());
		
		JPanel panelList= new JPanel( );
		panelList.setLayout( new BorderLayout( ) );
		panelList.setBorder( new CompoundBorder( new EmptyBorder( 4, 3, 3, 3 ), new TitledBorder( "List Accions" ) ) );

		panelList.setBackground(Color.WHITE);
	
		listAccions= new JList();
		listAccions.setSelectionMode( ListSelectionModel.SINGLE_SELECTION );
		listAccions.addListSelectionListener( this );

        JScrollPane scroll = new JScrollPane( );
        scroll.setBackground(Color.WHITE);
        scroll.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_NEVER );
        scroll.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        scroll.setBorder( new CompoundBorder( new EmptyBorder( 3, 3, 3, 3 ),new LineBorder( Color.BLACK, 1 ) ) );
        scroll.getViewport( ).add( listAccions );

        panelList.add( scroll, BorderLayout.CENTER );
        add( panelList, BorderLayout.CENTER );	
        
        setBackground(Color.WHITE);
	}
	
	@SuppressWarnings("unchecked")
	
	public void updateList( ArrayList<Accion> listUpdated )
	   {
		listAccions.setListData( listUpdated.toArray() );
		listAccions.setSelectedIndex( 0 );
	       

	   }
	public void selection( int seleccionado )
	   {
		listAccions.setSelectedIndex( seleccionado );
		listAccions.ensureIndexIsVisible( seleccionado );
	   }
	
	public boolean isSelectioned( ){
	       return !listAccions.isSelectionEmpty( );
	}
	
	public Accion getSelection( )   
	{
		Accion vSeleccionado = null;

	       if( listAccions.getSelectedValue( ) != null )
	       {
	           vSeleccionado = (Accion )listAccions.getSelectedValue( );
	       }

	       return vSeleccionado;	   
	}
	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if(listAccions.getSelectedValue( ) != null )
	       {
	           Accion p = ( Accion)listAccions.getSelectedValue( );
	           main.showInfo( p );
	       }
		
	}
	
	

}
