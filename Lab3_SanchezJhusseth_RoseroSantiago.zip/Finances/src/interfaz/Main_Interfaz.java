package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Accion;
import model.Fecha;
import model.Finances;

public class Main_Interfaz extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private List_Panel list;
	private Panel_Options options;
	private Graphics_Panel graphics;
	private Information info;
	
	private Finances fn;
	
	public Main_Interfaz(){
		panels();
		init();
		
		JPanel aux = new JPanel();
		aux.setLayout(new GridLayout(2,1,0,5));
		
		add(options, BorderLayout.WEST);
		
		JPanel aux1 = new JPanel();
		aux1.setLayout(new GridLayout(3,1));
		
		add(info, BorderLayout.EAST);
		
		aux.add(list);
		
		aux.add(graphics);
		
		add(aux, BorderLayout.CENTER);
		aux.setBackground(Color.WHITE);
		aux1.setBackground(Color.WHITE);
		 
		
		 setBackground(Color.WHITE);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public void panels(){
		list = new List_Panel(this);
		options = new Panel_Options(this);
		graphics = new Graphics_Panel();
		info = new Information(this);
		fn = new Finances();
		}
	
	public void init(){
		setLayout(new BorderLayout());
		setTitle("<<_ Finances _>>");
		setSize(780,600);
		
		setLocationRelativeTo(null);
	}
	
	
	public void showInfo(Accion a){
		info.setTxt_name(a.getName());
		info.setTxt_value("" + a.getValue());
		info.setTxt_ini("" + a.getFE().toString());
		info.setTxt_end("" + a.getFE().time());
	}
	
	public void edit(){
		info.showEdit(true);
	}
	
	public void save(){
		try{
		info.showEdit(false);
		Accion s = list.getSelection();
		s.setName(info.getTxt_name());
		s.setValue(Double.parseDouble(info.getTxt_value()));
		
		String dayI = info.getTxt_ini().charAt(0) +"" + info.getTxt_ini().charAt(1);
		String monthI = info.getTxt_ini().charAt(3) +"" + info.getTxt_ini().charAt(4);
		String yearI = info.getTxt_ini().charAt(6) +"" + info.getTxt_ini().charAt(7)+ info.getTxt_ini().charAt(8) +"" + info.getTxt_ini().charAt(9);
		
		String hour = info.getTxt_end().charAt(0) +"" + info.getTxt_end().charAt(1);
		String min = info.getTxt_end().charAt(3) +"" + info.getTxt_end().charAt(4);
		
		s.setFe(new Fecha(Integer.parseInt(dayI),Integer.parseInt(monthI),Integer.parseInt(yearI),Integer.parseInt(hour),Integer.parseInt(min)));
		
		}
		catch(Exception e){
			JOptionPane.showMessageDialog(this, "Values nulls or information empty");
		}
	}
	
	public void addAccions(){
		info.showEdit(true);
		info.clear();
		
		JFrame frame = new JFrame();
		
		JPanel aux = new JPanel();
		aux.setLayout(new GridLayout(4,2,5,5));
		
		JTextField txt_name = new JTextField(7);
		JTextField txt_value = new JTextField(7);
		JTextField txt_ini = new JTextField(7);
		JTextField txt_end = new JTextField(7);
		
		aux.add(new JLabel("Name: "));
		aux.add(txt_name);
		aux.add(new JLabel("Value: "));
		aux.add(txt_value);
		aux.add(new JLabel("Inicio:"));
		aux.add(txt_ini);
		aux.add(new JLabel("Final: "));
		aux.add(txt_end);
		
		int respuesta=JOptionPane.showConfirmDialog(frame, aux,JOptionPane.ICON_PROPERTY,JOptionPane.OK_CANCEL_OPTION);
		
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	    if(respuesta==JOptionPane.CANCEL_OPTION){
	    }
	    else{
	    	try{
	    		
	    		String name = txt_name.getText();
				double value = Double.parseDouble(txt_value.getText());
				
				String dayI = txt_ini.getText().charAt(0) +"" + txt_ini.getText().charAt(1);
				String monthI = txt_ini.getText().charAt(3) +"" + txt_ini.getText().charAt(4);
				String yearI = txt_ini.getText().charAt(6) +"" + txt_ini.getText().charAt(7)+ txt_ini.getText().charAt(8) +"" + txt_ini.getText().charAt(9);
				
				String hour = txt_end.getText().charAt(0) +"" + txt_end.getText().charAt(1);
				String min = txt_end.getText().charAt(3) +"" + txt_end.getText().charAt(4);
				
				Fecha ini = new Fecha(Integer.parseInt(dayI),Integer.parseInt(monthI),Integer.parseInt(yearI),Integer.parseInt(hour),Integer.parseInt(min));
				
				Accion nuevo = new Accion(name,ini,value); 
				fn.insert(nuevo);
	    		
	    	}
	    	catch(Exception e){
	    		JOptionPane.showMessageDialog(this, e.getMessage());
	    	}
	    }
		
	    list.updateList(fn.getAccions());
	}
	
	public void delete(){
		try{
		Accion nd = list.getSelection();
		fn.delete(nd);
		}
		catch(Exception e){
			JOptionPane.showMessageDialog(this, e.getMessage());
		}
		list.updateList(fn.getAccions());
	}
	
	public void searchAccions(String tip){
		
	}
	
	public void uploadData(){
		try{
		JFileChooser fc = new JFileChooser("./data");
		fc.setDialogTitle("Divisas");
		int resultado = fc.showOpenDialog(this);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			File archivo = fc.getSelectedFile();
			if (archivo != null) {
				File file = new File("data/" + archivo.getName());
				options.setTxt(archivo.getName());
				fn.cargar(file);
				list.updateList(fn.getAccions());
			}
		}
		}
		catch(Exception e){
//			JOptionPane.showMessageDialog(this, e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public void reboot(){
		options.setTxt(" ");
		fn.reboot();
		list.updateList(fn.getAccions());
		info.clear();
		repaint();
	}

	public void graphicsAccions() {
		
		try{
		int cant =0;
		
		Color co = Color.RED;
		
		if(cant<3){
			Accion ac = list.getSelection();
			int mI = ac.getFE().getDay();
			int mF = ac.getFE().getDay();
			String name = ac.getName();
			int v = (int) ac.getValue();
			graphics.paintAccion(graphics.getGraphics(), v, co,mI,mF,name);
			
			if(cant==1){
				co = Color.GREEN;
			}
			else if(cant==2){
				co = Color.BLUE;
			}
			
			cant++;
		}
		else{
			JOptionPane.showMessageDialog(this, "0nly 3 divisas");
		}
		}
		catch(Exception e){
			JOptionPane.showMessageDialog(this, "There isn�t accions selected");
		}

	}

	public void mayorAcion() {
		for(int i =0;i<fn.getAccions().size();i++){
			if(fn.getAccions().get(i)==fn.mayor()){
				list.selection(i);
			}
		}
	}

	public void menorAccions() {
		for(int i =0;i<fn.getAccions().size();i++){
			if(fn.getAccions().get(i)==fn.menor()){
				list.selection(i);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		
		Main_Interfaz window = new Main_Interfaz();
		window.setVisible(true);
	}
	
	
	


}
