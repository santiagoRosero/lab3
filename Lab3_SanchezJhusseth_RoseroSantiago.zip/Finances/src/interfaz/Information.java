package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Information extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String SAVE = "save";
	public static final String EDIT = "edit";
	
	
	private JTextField txt_name;
	private JTextField txt_value;
	private JTextField txt_ini;
	private JTextField txt_end;
	
	private JButton btnEdit;
	private JButton btnSave;
	
	private Main_Interfaz main;
	
	public Information(Main_Interfaz main){
		this.main = main;
		
		setLayout(new GridLayout(3,1));
		
		JPanel aux = new JPanel();
		aux.setLayout(new GridLayout(4,2,5,5));
		
		setLayout(new GridLayout(3,1));
		
		JPanel aux1 = new JPanel();
		aux1.setLayout(new GridLayout(1,2));
		
		JPanel aux2 = new JPanel();
		aux2.setLayout(new BorderLayout());
		
		txt_name = new JTextField(8);
		txt_value = new JTextField(8);
		txt_ini = new JTextField(8);
		txt_end = new JTextField(8);
		
		btnEdit = new JButton("Edit");
		btnEdit.setActionCommand(EDIT);
		btnEdit.addActionListener(this);
		
		btnSave = new JButton("Save");
		btnSave.addActionListener(this);
		btnSave.setActionCommand(SAVE);
		
		aux.add(new JLabel("Name: "));
		aux.add(txt_name);
		aux.add(new JLabel("Value: "));
		aux.add(txt_value);
		aux.add(new JLabel("Inicio:"));
		aux.add(txt_ini);
		aux.add(new JLabel("Hora: "));
		aux.add(txt_end);
		
		aux.setBackground(Color.WHITE);
		
		aux1.add(btnEdit);
		aux1.add(btnSave);
		
		aux1.setBackground(Color.WHITE);
		
		aux2.add(aux,BorderLayout.CENTER);
		aux2.add(aux1,BorderLayout.SOUTH);
		
		aux2.setBackground(Color.WHITE);
		
		aux1.setBorder( new CompoundBorder(new EmptyBorder( 15, 3, 3, 3 ), new LineBorder(Color.WHITE) ) );
		

		ImageIcon img = new ImageIcon("data/img_accions.jpg");
		
		JPanel im = new JPanel();
		im.setLayout(new BorderLayout());
		
		JLabel lb = new JLabel(img);
		
		lb.setBounds(100,100,100,100);
		im.add(lb, BorderLayout.CENTER);
		
		im.setBackground(Color.WHITE);
		
		
		ImageIcon img2 = new ImageIcon("data/logo_BVC.png");
		
		JPanel im2 = new JPanel();
		im2.setLayout(new BorderLayout());
		
		JLabel lb2 = new JLabel(img2);
		
		lb2.setBounds(100,100,100,100);
		im2.add(lb2, BorderLayout.CENTER);
		
		im2.setBackground(Color.WHITE);
		
		add(im);
		add(aux2);
		add(im2);
		
		setBackground(Color.WHITE);
		
		aux2.setBorder( new CompoundBorder(new EmptyBorder( 4, 3, 3, 3 ), new TitledBorder( "Information" ) ) );
		showEdit(false);
	}


	public String getTxt_name() {
		return txt_name.getText();
	}


	public void setTxt_name(String txt_name) {
		this.txt_name.setText(txt_name);
	}


	public String getTxt_value() {
		return txt_value.getText();
	}


	public void setTxt_value(String txt_value) {
		this.txt_value.setText(txt_value);
	}


	public String getTxt_ini() {
		return txt_ini.getText();
	}


	public void setTxt_ini(String txt_ini) {
		this.txt_ini.setText(txt_ini);
	}


	public String getTxt_end() {
		return txt_end.getText();
	}


	public void setTxt_end(String txt_end) {
		this.txt_end.setText(txt_end);
	}
	
	
	public void showEdit(boolean bo){
		txt_name.setEditable(bo);
		txt_value.setEditable(bo);
		txt_ini.setEditable(bo);
		txt_end.setEditable(bo);
	}
	
	public void clear(){
		txt_name.setText("");
		txt_value.setText("");
		txt_ini.setText("");
		txt_end.setText("");
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		 String command = e.getActionCommand();
		 
		 if(command.equals(EDIT)){
			 main.edit();
		 }
		 else if (command.equals(SAVE)){
			 main.save();
		 }
	}
	

}
