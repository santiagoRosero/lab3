package interfaz;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class Graphics_Panel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public Graphics_Panel(){
		setBorder( new CompoundBorder(new EmptyBorder( 4, 3, 3, 3 ), new TitledBorder( "Graphics" ) ) );
		setBackground(Color.WHITE);
	}
	
	@Override
	public void paint(Graphics g){
		
		Graphics2D gr =(Graphics2D) g;
		
		BasicStroke stroke = new BasicStroke(2);
        ((Graphics2D)g).setStroke(stroke); 
		
		gr.drawLine(55, 25, 55, 255);
		gr.drawLine(55, 255,340, 255);
		
		Font fuente=new Font("Monospaced",Font.BOLD, 16);
		gr.setFont(fuente);
		
		gr.drawString("Y(USD)", 30, 22);
		
		gr.drawString("X(Month)", 343, 259);
		
		Font fuent =new Font("Monospaced",Font.BOLD, 11);
		gr.setFont(fuent);
		
		gr.drawString("0", 52, 265);
		
		
		gr.drawString("10", 26, 192);
		gr.drawString("20", 26, 129);
		gr.drawString("30", 26, 66);
		
		gr.drawString("04", 126, 265);
		gr.drawString("08", 197, 265);
		gr.drawString("12", 268, 265);
		
		
	}
	
	public void paintAccion(Graphics g, int value, Color co, int monthI,int monthF, String name){
		int x1 = 79;int x2 = 103;int x3 = 127;int x4 = 151;int x5 = 175;int x6 = 199;int x7 = 223;int x8 = 247;int x9 = 271;int x10 = 295;
		
		int x =0; int xF = 0; int y =0;
		
		if(monthI==1){
			x=x1;
		}
		
		else if(monthI==2){
			x=x2;
		}
		

		else if(monthI==3){
			x=x3;
		}
		
		else if(monthI==4){
			x=x4;
		}
		

		else if(monthI==5){
			x=x5;
		}
		
		else if(monthI==6){
			x=x6;
		}
        

		else if(monthI==7){
			x=x7;
		}


		else if(monthI==8){
			x=x8;
		}
		

		else if(monthI==9){
			x=x9;
		}
		
		else if(monthI==10){
			x=x10;
		}
		
		if(monthF==1){
			xF=x1;
		}
		
		else if(monthF==2){
			xF=x2;
		}
		

		else if(monthF==3){
			xF=x3;
		}
		
		else if(monthF==4){
			xF=x4;
		}
		

		else if(monthF==5){
			xF=x5;
		}
		
		else if(monthF==6){
			xF=x6;
		}
        

		else if(monthF==7){
			xF=x7;
		}


		else if(monthF==8){
			xF=x8;
		}
		

		else if(monthF==9){
			xF=x9;
		}
		
		else if(monthF==10){
			xF=x10;
		}

		
		if(value >0 && value < 10){
			y = 223;
		}
		
		if(value >10 && value < 20){
			y = 160;
		}
		
		if(value >20 && value < 30){
			y = 97;
		}
		
		g.setColor(co);
		
		g.drawLine(x, y, xF, y);
		
		
		Font fuente=new Font("Monospaced",Font.ITALIC, 9);
		g.setFont(fuente);
		
		int xm = (xF-x)/2 + x;
		g.drawString(name, xm, y-3);
		
		
	}
	

}
