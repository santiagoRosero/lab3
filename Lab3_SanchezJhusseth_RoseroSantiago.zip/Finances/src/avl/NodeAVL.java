package avl;

import java.io.Serializable;

import estructures.ConcatenateQueue;
import estructures.QueueEmptyException;
import estructures.IteratorException;
import estructures.IteratorSimple;
import tree.ElementSameException;
import tree.ElementNullException;

public class NodeAVL<T extends Comparable<? super T>> implements Serializable
{
	public static final long serialVersionUID = 1L;

    public static final int BIZQ = 1;

    public static final int BAL = 0;

    public static final int BDER = -1;

    public T elem;

    public NodeAVL<T> rigthNode;

    public NodeAVL<T> leftNode;

    public int balance;

    public NodeAVL( T pElement )
    {
        elem = pElement;
        rigthNode = null;
        leftNode = null;
    }

    public T gerRoot( )
    {
        return elem;
    }

    public NodeAVL<T> getSonRigth( )
    {
        return rigthNode;
    }

    public NodeAVL<T> getSonLeft( )
    {
        return leftNode;
    }

    public NodeAVL<T> insert( T pElement ) throws ElementSameException
    {
        Retorno retorno = new Retorno( null, false );
        auxInsertar( pElement, retorno );
        return retorno.answer;
    }

    public NodeAVL<T> eliminar( T pElemento ) throws ElementNullException
    {
        Retorno retorno = new Retorno( null, false );
        auxEliminar( pElemento, retorno );
        return retorno.answer;
    }

    public T buscar( T modelo )
    {
        int resultado = elem.compareTo( modelo );
        if( resultado == 0 )
        {
            return elem;
        }
        else if( resultado > 0 )
        {
            
            return ( leftNode != null ) ? leftNode.buscar( modelo ) : null;
        }
        else
        {
            return ( rigthNode != null ) ? rigthNode.buscar( modelo ) : null;
        }
    }

    public void inorden( IteratorSimple<T> resultado )
    {
        if( leftNode != null )
        {
            leftNode.inorden( resultado );
        }

        try
        {
            resultado.add( elem );
        }
        catch( IteratorException e )
        {
        }

        if( rigthNode != null )
        {
            rigthNode.inorden( resultado );
        }
    }

    public int darAltura( )
    {
        int a1 = ( leftNode == null ) ? 0 : leftNode.darAltura( );
        int a2 = ( rigthNode == null ) ? 0 : rigthNode.darAltura( );
        return ( a1 >= a2 ) ? a1 + 1 : a2 + 1;
    }

    public T darMayor( )
    {
        NodeAVL<T> nodo = mayorElemento( );
        return ( nodo == null ) ? null : nodo.gerRoot( );
    }

    public T darMenor( )
    {
        NodeAVL<T> nodo = menorElemento( );
        return ( nodo == null ) ? null : nodo.gerRoot( );
    }

   
    public void auxInsertar( T pElemento, Retorno retorno ) 
    {
        int resultado = elem.compareTo( pElemento );
        if( resultado == 0 )
        {
        	return;
        }
        else if( resultado > 0 )
        {
            if( leftNode == null )
            {
                leftNode = new NodeAVL<T>( pElemento );
                retorno.answer = this;
                if( rigthNode == null )
                {
                    balance = BIZQ;
                    retorno.diferenciaAltura = true;
                }
                else
                {
                    balance = BAL;
                    retorno.diferenciaAltura = false;
                }
            }
            else
            {
                leftNode.auxInsertar( pElemento, retorno );
                leftNode = retorno.answer;
          
                if( retorno.diferenciaAltura )
                {
                    switch( balance )
                    {
                        case BIZQ:
                            retorno.diferenciaAltura = false;
                            retorno.answer = balanceaIzq( );
                            break;
                        case BAL:
                            balance = BIZQ;
                            retorno.answer = this;
                            break;
                        case BDER:
                            balance = BAL;
                            retorno.diferenciaAltura = false;
                            retorno.answer = this;
                            break;
                    }
                }
                else
                {
                    retorno.answer = this;
                }
            }
        }
        else
        {
            if( rigthNode == null )
            {
                rigthNode = new NodeAVL<T>( pElemento );
                retorno.answer = this;
                if( leftNode == null )
                {
                    balance = BDER;
                    retorno.diferenciaAltura = true;
                }
                else
                {
                    balance = BAL;
                    retorno.diferenciaAltura = false;
                }
            }
            else
            {
                rigthNode.auxInsertar( pElemento, retorno );
                rigthNode = retorno.answer;

                if( retorno.diferenciaAltura )
                {
                    switch( balance )
                    {
                        case BIZQ:
                            balance = BAL;
                            retorno.diferenciaAltura = false;
                            retorno.answer = this;
                            break;
                        case BAL:
                            balance = BDER;
                            retorno.answer = this;
                            break;
                        case BDER:
                            retorno.diferenciaAltura = false;
                            retorno.answer = balanceaDer( );
                            break;
                    }
                }
                else
                {
                    retorno.answer = this;
                }
            }
        }
    }

    public void auxEliminar( T pElemento, Retorno retorno ) throws ElementNullException
    {
        int resultado = elem.compareTo( pElemento );
        if( resultado == 0 )
        {

            if( leftNode == null & rigthNode == null )
            {

                retorno.diferenciaAltura = true;
                retorno.answer = null;
            }
            else if( leftNode == null )
            {
                retorno.answer = rigthNode;
                retorno.diferenciaAltura = true;
            }
            else
            {
                NodeAVL<T> reemplazo = leftNode.mayorElemento( );
                elem = reemplazo.elem;
                leftNode.auxEliminar( reemplazo.elem, retorno );
                leftNode = retorno.answer;

                if( retorno.diferenciaAltura )
                {
                    balanElimDer( retorno );
                }
                else
                {
                    retorno.answer = this;
                }
            }
        }
        else if( resultado > 0 )
        {
        	
            if( leftNode == null )
            {
                //throw new ElementoNoExisteException( "El elemento no se encuentra en el �rbol" );
            }
            else{
            leftNode.auxEliminar( pElemento, retorno );
            leftNode = retorno.answer;

            if( retorno.diferenciaAltura )
            {
                balanElimDer( retorno );
            }
            else
            {
                retorno.answer = this;
            }}
        }
        else
        {
            if( rigthNode == null )
            {

                //throw new ElementoNoExisteException( "El elemento no se encuentra en el �rbol" );
            }
            else{
            rigthNode.auxEliminar( pElemento, retorno );
            rigthNode = retorno.answer;               
            }
            
            if( retorno.diferenciaAltura )
            {
                balanElimIzq( retorno );
            }
            else
            {
                retorno.answer = this;
            }
        }
    }

    public NodeAVL<T> balanceaIzq( )
    {
        if( leftNode.balance == BIZQ )
        {
            balance = BAL;
            leftNode.balance = BAL;
            return roteDer( );
        }
        else
        {
            switch( leftNode.rigthNode.balance )
            {
                case BIZQ:
                    balance = BDER;
                    leftNode.balance = BAL;
                    break;
                case BAL:
                    balance = BAL;
                    leftNode.balance = BAL;
                    break;
                case BDER:
                    balance = BAL;
                    leftNode.balance = BIZQ;
                    break;
            }
            leftNode.rigthNode.balance = BAL;
            return roteIzqDer( );
        }
    }

    public NodeAVL<T> balanceaDer( )
    {
        if( rigthNode.balance == BDER )
        {
            balance = BAL;
            rigthNode.balance = BAL;
            return roteIzq( );
        }
        else
        {
            switch( rigthNode.leftNode.balance )
            {
                case BIZQ:
                    balance = BAL;
                    rigthNode.balance = BDER;
                    break;
                case BAL:
                    balance = BAL;
                    rigthNode.balance = BAL;
                    break;
                case BDER:
                    balance = BIZQ;
                    rigthNode.balance = BAL;
                    break;
            }
            rigthNode.leftNode.balance = BAL;
            return roteDerIzq( );
        }
    }

    public NodeAVL<T> roteIzq( )
    {
        NodeAVL<T> temp = rigthNode;
        if (temp == null)
            return null;
        rigthNode = temp.leftNode;
        temp.leftNode = this;
        return temp;
    }

    public NodeAVL<T> roteDer( )
    {
        NodeAVL<T> temp = leftNode;
        if (temp == null)
            return null;
        leftNode = temp.rigthNode;
        temp.rigthNode = this;
        return temp;
    }

    public NodeAVL<T> roteDerIzq( )
    {
        rigthNode = rigthNode.roteDer( );
        return roteIzq( );
    }
    
    public NodeAVL<T> roteIzqDer( )
    {
        leftNode = leftNode.roteIzq( );
        return roteDer( );
    }

    public void balanElimDer( Retorno retorno )
    {
        switch( balance )
        {
            case BIZQ:
                balance = BAL;
                retorno.answer = this;
                break;
            case BAL:
                balance = BDER;
                retorno.diferenciaAltura = false;
                retorno.answer = this;
                break;
            case BDER:
                if( rigthNode != null){
                if( rigthNode.balance != BIZQ )
                {
                    retorno.answer = roteIzq( );
                    if( retorno.answer.balance == BAL )
                    {
                        retorno.answer.balance = BIZQ;
                        retorno.answer.leftNode.balance = BDER;
                        retorno.diferenciaAltura = false;
                    }
                    else
                    {
                        retorno.answer.balance = BAL;
                        retorno.answer.leftNode.balance = BAL;
                    }
                }
                else
                {
                    retorno.answer = roteDerIzq( );
                    if( retorno.answer != null){
                    if( retorno.answer.balance == BDER )
                    {
                        retorno.answer.leftNode.balance = BIZQ;
                    }
                    else
                    {
                        retorno.answer.leftNode.balance = BAL;
                    }
                    if( retorno.answer.balance == BIZQ )
                    {
                        retorno.answer.rigthNode.balance = BDER;
                    }
                    else
                    {
                        retorno.answer.rigthNode.balance = BAL;
                    }
                    retorno.answer.balance = BAL;
                }}}
                break;
        }
    }

    public void balanElimIzq( Retorno retorno )
    {
        switch( balance )
        {
            case BIZQ:
                if( leftNode != null){
                if( leftNode.balance != BDER )
                {
                    retorno.answer = roteDer( );
                    if( retorno.answer.balance == BAL )
                    {
                        retorno.answer.balance = BDER;
                        retorno.answer.rigthNode.balance = BIZQ;
                        retorno.diferenciaAltura = false;
                    }
                    else
                    {
                        retorno.answer.balance = BAL;
                        retorno.answer.rigthNode.balance = BAL;
                    }
                }
                else
                {
                    retorno.answer = roteIzqDer( );
                    if(retorno.answer != null){
                    if( retorno.answer.balance == BIZQ )
                    {
                        retorno.answer.rigthNode.balance = BDER;
                    }
                    else
                    {
                        retorno.answer.rigthNode.balance = BAL;
                    }
                    if( retorno.answer.balance == BDER )
                    {
                        retorno.answer.leftNode.balance = BIZQ;
                    }
                    else
                    {
                        retorno.answer.leftNode.balance = BAL;
                    }
                    retorno.answer.balance = BAL;
                }}}
                break;
            case BAL:
                balance = BIZQ;
                retorno.diferenciaAltura = false;
                retorno.answer = this;
                break;
            case BDER:
                balance = BAL;
                retorno.answer = this;
                break;
        }
    }

    public NodeAVL<T> mayorElemento( )
    {
        return ( rigthNode == null ) ? this : rigthNode.mayorElemento( );
    }

    public NodeAVL<T> menorElemento( )
    {
        return ( leftNode == null ) ? this : leftNode.menorElemento( );
    }

    public void getRecorrLevels( IteratorSimple<T> result )
    {
        ConcatenateQueue<NodeAVL<T>> queue = new ConcatenateQueue<NodeAVL<T>>( );
        queue.insert( this );
        while( queue.getLongitude( ) != 0 )
        {
            NodeAVL<T> node = null;
            try
            {
                node = queue.takeElement( );
            }
            catch( QueueEmptyException e )
            {
            	
            }
            try
            {
                result.add( node.elem );
            }
            catch( IteratorException e )
            {
            	
            }
            
            if( node.leftNode != null )
            {
                queue.insert( node.leftNode );
            }
            if( node.rigthNode != null )
            {
                queue.insert( node.rigthNode );
            }
        }
    }

    public class Retorno
    {

        public NodeAVL<T> answer;

        public boolean diferenciaAltura;

        public Retorno( NodeAVL<T> pAnswer, boolean pDiferenciaAltura )
        {
            answer = pAnswer;
            diferenciaAltura = pDiferenciaAltura;
        }
    }
}
