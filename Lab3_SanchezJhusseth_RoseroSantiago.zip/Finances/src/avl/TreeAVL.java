package avl;

import java.io.Serializable;

import estructures.Iterator;
import estructures.IteratorSimple;
import tree.ElementSameException;
import tree.ElementNullException;
import tree.IOrderTree;

public class TreeAVL<T extends Comparable<? super T>> implements Serializable, IOrderTree<T>
{
	public static final long serialVersionUID = 1L;

    public NodeAVL<T> root;

    public int weigth;
    
    public TreeAVL( )
    {
        root = null;
        weigth = 0;
    }

    public TreeAVL( NodeAVL<T> r, int p )
    {
        root = r;
        weigth = p;
    }

    public NodeAVL<T> getRoot( )
    {
        return root;
    }

    public void insert( T element ) throws ElementSameException
    {
        if( root == null )
        {
            root = new NodeAVL<T>( element );
        }
        else
        {
            root = root.insert( element );
        }
        weigth++;
    }

    public void delete( T element ) throws ElementNullException
    {
        if( root != null )
        {
            root = root.eliminar( element );
            weigth--;
        }
    }

    public T search( T model )
    {
        return ( root != null ) ? root.buscar( model ) : null;
    }

    public Iterator<T> inorden( )
    {
        IteratorSimple<T> result = new IteratorSimple<T>( weigth );
        if( root != null )
        {
            root.inorden( result );
        }
        return result;
    }

    public int darAltura( )
    {
        return ( root != null ) ? root.darAltura( ) : 0;
    }

    public int getWeigth( )
    {
        return weigth;
    }

    public T darMayor( )
    {
        return ( root != null ) ? root.darMayor( ) : null;
    }

    public T darMenor( )
    {
        return ( root != null ) ? root.darMenor( ) : null;
    }

    public Iterator<T> getRecorrLevels( )
    {
        IteratorSimple<T> result = new IteratorSimple<T>( getWeigth( ) );
        if( root != null )
        {
            root.getRecorrLevels( result );
        }
        return result;
    }
}
