package red_black;

import java.io.Serializable;
import java.util.List;

import tree.ElementSameException;
import tree.ElementNullException;

public class Node_RB<T extends Comparable<? super T>> implements Serializable
{
	private static final long serialVersionUID = 1L;
		
    public static final int BLACK = 1;

    public static final int RED = 0;

    private Node_RB<T> rigthSon;

    private Node_RB<T> leftSon;

    private T elem;

    private int color;

    private Node_RB<T> father;

    protected Node_RB( T elem )
    {
        this.elem = elem;
        color = RED;
        changeSonRigth( new Node_RB<T>( ) );
        changeSonLeft( new Node_RB<T>( ) );
        father = null;
    }

    private Node_RB( )
    {
        this.elem = null;
        color = BLACK;
        father = null;
    }

    public Node_RB<T> getFather( )
    {
        return father;
    }

    public Node_RB<T> getTio( )
    {
        if( father == null || father.father == null )
        {
            return null;
        }
        else
        {
            if( father.father.isRigthSon( father ) )
                return father.father.leftSon;
            else
                return father.father.rigthSon;
        }

    }

    public int getColor( )
    {
        return color;
    }

    public Node_RB<T> getRigthSon( )
    {
        return rigthSon;
    }

    public boolean isRigthSon( Node_RB<T> node )
    {
        return rigthSon == node;
    }

    public Node_RB<T> getLeftSon( )
    {
        return leftSon;
    }

    public boolean isLeftSon( Node_RB<T> node )
    {
        return leftSon == node;
    }

    public boolean hijoDerechoHoja( )
    {
        return rigthSon.elem == null;
    }

    public boolean hijoIzquierdoHoja( )
    {
        return leftSon.elem == null;
    }

    public Node_RB<T> darMayor( )
    {
        return hijoDerechoHoja( ) ? this : rigthSon.darMayor( );
    }

    public Node_RB<T> darMenor( )
    {
        return hijoIzquierdoHoja( ) ? this : leftSon.darMenor( );
    }

    public void getPreorder( List<T> preorder )
    {
        preorder.add( elem );
        if( !hijoIzquierdoHoja( ) )
            leftSon.getPreorder( preorder );
        if( !hijoDerechoHoja( ) )
            rigthSon.getPreorder( preorder );
    }

    public boolean esHoja( )
    {
        return elem == null;
    }

    public int getWeigth( )
    {
        return esHoja( ) ? 0 : 1 + rigthSon.getWeigth( ) + leftSon.getWeigth( );
    }

    public void darHojas( List<Node_RB<T>> hojas )
    {
        if( esHoja( ) )
            hojas.add( this );
        else
        {
            if( !hijoDerechoHoja( ) )
                rigthSon.darHojas( hojas );
            if( !hijoIzquierdoHoja( ) )
                leftSon.darHojas( hojas );
        }
    }

    public int darAltura( )
    {
        if( esHoja( ) )
            return 0;
        int a1 = leftSon.darAltura( );
        int a2 = rigthSon.darAltura( );
        return ( a1 >= a2 ) ? a1 + 1 : a2 + 1;
    }

    public boolean exist( T e )
    {
        try
        {
            getNode( e );
            return true;
        }
        catch( ElementNullException e1 )
        {
            return false;
        }

    }

    public Node_RB<T> getNode( T elem ) throws ElementNullException
    {
        int comp = elem.compareTo( this.elem );
        if( comp == 0 )
            return this;
        else if( comp < 0 )
        {
            if( !hijoIzquierdoHoja( ) )
                return leftSon.getNode( elem );
            else
                return null;
               // throw new ElementoNoExisteException( "El elemento buscado no existe" );
        }
        else
        {
            if( !hijoDerechoHoja( ) )
                return rigthSon.getNode( elem );
            else
                return null;
               // throw new ElementoNoExisteException( "El elemento buscado no existe" );
        }

    }

    public T getInfoNode( )
    {
        return elem;
    }

    public boolean sonRigthBlack( )
    {
        return rigthSon.color == BLACK;
    }

    public boolean sonLeftBlack( )
    {
        return leftSon.color == BLACK;
    }

    public boolean childrenBlack( )
    {
        return sonRigthBlack( ) && sonLeftBlack( );
    }

    public Node_RB<T> getBrother( )
    {
        if( father == null )
            return null;
        else
            return father.isRigthSon( this ) ? father.leftSon : father.rigthSon;
    }

    private void changeFather( Node_RB<T> father )
    {
        this.father = father;
    }

    protected void changeColor( int color )
    {
        this.color = color;
    }

    private void changeSonRigth( Node_RB<T> son )
    {
        if( son != null )
            son.changeFather( this );
        rigthSon = son;
    }

    private void changeSonLeft( Node_RB<T> son )
    {
        if( son != null )
            son.changeFather( this );
        leftSon = son;
    }

    private void changeElement( Node_RB<T> node )
    {
        if( node.elem != null )
        {
            T aux = elem;            elem = node.elem;
            node.elem = aux;
        }
        else
        {
            elem = null;
            color = BLACK;
            rigthSon = leftSon = null;
        }
    }

    private Node_RB<T> rotationLeft( )
    {
        if( hijoDerechoHoja( ) )
            return this;
        else
        {
            Node_RB<T> sonRigthAux = rigthSon;
            changeSonRigth( sonRigthAux.getLeftSon( ) );
            sonRigthAux.changeFather( father );
            sonRigthAux.changeSonLeft( this );
            return sonRigthAux;
        }
    }

    private Node_RB<T> rotationRigth( )
    {
        if( hijoIzquierdoHoja( ) )
            return this;
        else
        {
            Node_RB<T> sonLeftAux = leftSon;
            changeSonLeft( sonLeftAux.getRigthSon( ) );
            sonLeftAux.changeFather( father );
            sonLeftAux.changeSonRigth( this );
            return sonLeftAux;
        }
    }

    protected Node_RB<T> insert( Node_RB<T> node ) throws ElementSameException
    {
        normalInsert( node );
        Retorno r = new Retorno( null );
        node.balaceRedBlackCase1( r );
        return r.answer;
    }

    private void normalInsert( Node_RB<T> node ) throws ElementSameException
    {
        if( elem.compareTo( node.getInfoNode( ) ) == 0 )
        {
            //throw new ElementoExisteException( "El elemento " + nodo.darInfoNodo( ).toString( ) + " ya existe en el �rbol" );
        }
        else if( elem.compareTo( node.getInfoNode( ) ) < 0 )
        {
            if( hijoDerechoHoja( ) )
            {
                rigthSon = node;
                node.changeFather( this );
            }
            else
            {
                rigthSon.normalInsert( node );
            }
        }
        else
        {
            if( hijoIzquierdoHoja( ) )
            {
                leftSon = node;
                node.changeFather( this );
            }
            else
            {
                leftSon.normalInsert( node );
            }
        }
    }

    private Node_RB<T> balaceRedBlackCase1( Retorno r )
    {
        if( father == null )
        {
            color = BLACK;
            r.answer = this;
        }
        else
        {
            balanceRedBlackCase2( r );
        }
        return r.answer;
    }


    private void balanceRedBlackCase2( Retorno r )
    {
        if( father.getColor( ) == RED )
            balanceRedBlackCase3( r );
        else
            r.answer = null;

    }

    private void balanceRedBlackCase3( Retorno r )
    {
        Node_RB<T> tio = getTio( );
        Node_RB<T> grandFather = father.getFather( );
        r.answer = null;

        if( !tio.esHoja( ) && tio.getColor( ) == RED )
        {
            getFather( ).changeColor( BLACK );
            tio.changeColor( BLACK );
            grandFather.changeColor( RED );
            grandFather.balaceRedBlackCase1( r );
        }
        else
        {
            balanceRedBlackCase4( r );
        }
    }

    private void balanceRedBlackCase4( Retorno r )
    {
        Node_RB<T> grandFather = father.getFather( );
        r.answer = null;

        if( father.isRigthSon( this ) && grandFather.isLeftSon( father ) )
        {
            grandFather.changeSonLeft( father.rotationLeft( ) );
            leftSon.balanceRedBlackCase5( r );
        }
        else if( father.isLeftSon( this ) && grandFather.isRigthSon( father ) )
        {
            grandFather.changeSonRigth( father.rotationRigth( ) );
            rigthSon.balanceRedBlackCase5( r );
        }
        else
        {
            balanceRedBlackCase5( r );
        }
    }

    private void balanceRedBlackCase5( Retorno r )
    {
        Node_RB<T> grandFather = father.getFather( );

        father.changeColor( BLACK );
        grandFather.changeColor( RED );

        if( father.isLeftSon( this ) && grandFather.isLeftSon( father ) )
        {
            if( grandFather.getFather( ) == null )
                grandFather.rotationRigth( );
            else if( grandFather.getFather( ).isRigthSon( grandFather ) )
                grandFather.getFather( ).changeSonRigth( grandFather.rotationRigth( ) );
            else
                grandFather.getFather( ).changeSonLeft( grandFather.rotationRigth( ) );

        }
        else
        {
            if( grandFather.getFather( ) == null )
                grandFather.rotationLeft( );
            else if( grandFather.getFather( ).isRigthSon( grandFather ) )
                grandFather.getFather( ).changeSonRigth( grandFather.rotationLeft( ) );
            else
                grandFather.getFather( ).changeSonLeft( grandFather.rotationLeft( ) );
        }
        r.answer = father;
    }

    protected Node_RB<T> delete( )
    {
        Node_RB<T> refactor = !hijoIzquierdoHoja( ) ? leftSon.darMayor( ) : this.darMenor( );

        changeElement( refactor );

        Retorno r = new Retorno( null );
        refactor.deleteRedBlack( r );

        return r.answer;
    }

    private void deleteChildren( )
    {
        rigthSon = new Node_RB<T>( );
        leftSon = new Node_RB<T>( );
    }

    private void deleteRedBlack( Retorno r )
    {
        Node_RB<T> son = !hijoDerechoHoja( ) ? rigthSon : leftSon;

        int colorDelete = getColor( );
        int colorSon = son.getColor( );

        changeElement( son );
        deleteChildren( );

        if( colorSon == RED )
        {
            r.answer = this;
            return;
        }
        else if( colorSon == BLACK && colorDelete == RED )
        {
            r.answer = this;
            changeColor( BLACK );
        }
        else
        {
            deleteCase1( r );
        }
    }

    private void deleteCase1( Retorno r )
    {
        if( father != null )
            this.deleteCase2( r );
        else
            r.answer = null;
    }

    private void deleteCase2( Retorno r )
    {
        Node_RB<T> brother = getBrother( );

        if( brother.color == RED )
        {
            father.color = RED;
            brother.color = BLACK;

            r.answer = brother;

            Node_RB<T> grandFather = father.father;
            if( father.isRigthSon( this ) )
            {
                if( grandFather != null )
                {
                    if( grandFather.isRigthSon( father ) )
                        grandFather.changeSonRigth( father.rotationRigth( ) );
                    else
                        grandFather.changeSonLeft( father.rotationRigth( ) );
                }
                else
                    father.rotationRigth( );
            }
            else
            {
                if( grandFather != null )
                {
                    if( grandFather.isRigthSon( father ) )
                        grandFather.changeSonRigth( father.rotationLeft( ) );
                    else
                        grandFather.changeSonLeft( father.rotationLeft( ) );
                }
                else
                    father.rotationLeft( );
            }
        }
        deleteCase3( r );
    }

    private void deleteCase3( Retorno r )
    {
    	
        Node_RB<T> brother = getBrother( );

        if( father.color == BLACK && brother.color == BLACK && brother.childrenBlack( ) )
        {
            brother.changeColor( RED );
            father.deleteCase1( r );
        }
        else
        {
            deleteCase4( r );
        }
    }

    private void deleteCase4( Retorno r )
    {
        Node_RB<T> brother = getBrother( );

        if( father.color == RED && brother.color == BLACK && brother.childrenBlack( ) )
        {
            brother.changeColor( RED );
            father.changeColor( BLACK );
        }
        else
        {
            deleteCase5( r );
        }
    }

    private void deleteCase5( Retorno r )
    {
        Node_RB<T> brother = getBrother( );

        if( father.isLeftSon( this ) && brother.color == BLACK && !brother.sonLeftBlack( ) && brother.sonRigthBlack( ) )
        {
            brother.color = RED;
            brother.leftSon.color = BLACK;
            father.changeSonRigth( brother.rotationRigth( ) );
        }
        else if( father.isRigthSon( this ) && brother.color == BLACK && !brother.sonRigthBlack( ) && brother.sonLeftBlack( ) )
        {
            brother.color = RED;
            brother.rigthSon.color = BLACK;
            father.changeSonLeft( brother.rotationLeft( ) );
        }
        deleteCase6( r );
    }

    private void deleteCase6( Retorno r )
    {
        Node_RB<T> brother = getBrother( );

        brother.color = father.color;
        father.color = BLACK;
        Node_RB<T> grandFather = father.father;

        r.answer = brother;

        if( father.isLeftSon( this ) )
        {
            brother.rigthSon.color = BLACK;

            if( grandFather != null )
            {
                if( grandFather.isRigthSon( father ) )
                    grandFather.changeSonRigth( father.rotationLeft( ) );
                else
                    grandFather.changeSonLeft( father.rotationLeft( ) );
            }
            else
                father.rotationLeft( );
        }
        else
        {
            brother.leftSon.color = BLACK;

            if( grandFather != null )
            {
                if( grandFather.isRigthSon( father ) )
                    grandFather.changeSonRigth( father.rotationRigth( ) );
                else
                    grandFather.changeSonLeft( father.rotationRigth( ) );
            }
            else
                father.rotationRigth( );
        }
    }

    
    public String toString( )
    {
        return ( elem != null ? elem.toString( ) : "null" ) + ( color == RED ? " red" : " black" );
    }
    
    
    private class Retorno
    {
        private Node_RB<T> answer;
        
        private Retorno( Node_RB<T> pAnswer )
        {
            answer = pAnswer;
        }
    }
}