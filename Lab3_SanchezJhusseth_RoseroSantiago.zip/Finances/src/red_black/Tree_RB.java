
package red_black;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import tree.ElementSameException;
import tree.ElementNullException;
import tree.IOrderTree;


public class Tree_RB<T extends Comparable<? super T>> implements Serializable, IOrderTree<T>
{
	private static final long serialVersionUID = 1L;

    private Node_RB<T> root;
    
    public Tree_RB( )
    {
        root = null;
    }

    public void insert( T elem ) throws ElementSameException
    {
    	
        Node_RB<T> node = new Node_RB<T>( elem );

        Node_RB<T> r2 = null;

        if( root == null )
        {
            root = node;
            root.changeColor( Node_RB.BLACK );
        }
        else
        {
            r2 = root.insert( node );
        }

        root = r2 != null && r2.getFather( ) == null ? r2 : root;
    }

    public void delete( T elem ) throws ElementNullException
    {
        if( root != null ){
        	if( root.getInfoNode( ).compareTo( elem ) == 0 && root.hijoDerechoHoja( ) && root.hijoIzquierdoHoja( ) )
            root = null;
        
        	else
        
        	{   
        		if (root.getNode(elem) != null)
        		{
        			Node_RB<T> r2 = root.getNode( elem ).delete( );            
        			root = r2 != null && r2.getFather( ) == null ? r2 : root;
        		}
        		else{
        			throw new ElementNullException( "No se encuentra el elemento" );
        		}
        	}
        }
        else{
        	throw new ElementNullException( "El Arbol se encuentra vacio" );
        }
    }

    public List<T> getPreorder( )
    {
        List<T> preorder = new LinkedList<T>( );
        if( root != null )
            root.getPreorder( preorder );
        return preorder;
    }
    
    public boolean exist( T elem )
    {
        return root != null ? root.exist( elem ) : false;
    }

    public T search( T model )
    {
        try
        {   
            if (root.getNode(model)== null)
                return null; 
            return root != null ? root.getNode( model ).getInfoNode( ) : null;
        }
        catch( ElementNullException e )
        {
            return null;
        }
    }

    public Node_RB<T> getRoot( )
    {
        return root;
    }

    
    public int getWeigth( )
    {
        return root == null ? 0 : root.getWeigth( );
    }

    public int darAltura( )
    {
        return root == null ? 0 : root.darAltura( );
    }

    public T darMinimo( )
    {
        return root == null ? null : root.darMenor( ).getInfoNode( );
    }

    public T darMayor( )
    {
        return root == null ? null : root.darMayor( ).getInfoNode( );
    }
}