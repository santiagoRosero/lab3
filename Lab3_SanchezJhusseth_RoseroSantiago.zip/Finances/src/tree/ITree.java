package tree;

public interface ITree<T> 
{
    public int darAltura();
    
    public int getWeigth();
    
    public T search(T model);
    
}
