package tree;

public interface IOrderTree<T extends Comparable<? super T>> extends ITree<T>  
{
    public void insert( T elem ) throws ElementSameException;
    public void delete( T elem ) throws ElementNullException;

}
