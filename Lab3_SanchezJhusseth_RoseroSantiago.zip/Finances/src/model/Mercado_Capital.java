package model;

import java.util.ArrayList;

import avl.TreeAVL;

public class Mercado_Capital {
	
	private String name;
	private double total;
	
	private ArrayList<Mercado_Divisas> markets;
	
//	private TreeAVL<Mercado_Divisas> marketD;

	public Mercado_Capital(String name, double total){
		this.name = name;
		this.total= total;
		markets = new ArrayList<>();
//		marketD = new TreeAVL<>();
	}
	public Mercado_Capital(){
		this.name = "";
		this.total= 0;
		markets = new ArrayList<>();
//		marketD = new TreeAVL<>();
	}
	
//	public TreeAVL<Mercado_Divisas> getMarketD() {
//		return marketD;
//	}
//
//	public void setMarketD(TreeAVL<Mercado_Divisas> marketD) {
//		this.marketD = marketD;
//	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public ArrayList<Mercado_Divisas> getMarkets() {
		return markets;
	}

	public void setMarkets(ArrayList<Mercado_Divisas> markets) {
		this.markets = markets;
	}
	
	@Override
	public String toString() {
		return name;
	}

}
