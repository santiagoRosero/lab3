package model;

import java.util.Date;

public class Accion implements Comparable<Accion>{
	
	private double value;
    private Fecha fe;
    private String name;
    
    public Accion(String name,Fecha fe, double value){
    	this.fe = fe;
    	this.value = value;
    	this.name = name;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
	public Fecha getFE() {
		return fe;
	}

	public void setFe(Fecha fe) {
		this.fe = fe;
	}
	
	@Override
	public String toString() {
		return name + "   "  + fe.getHour() + ":" + fe.getMin();
	}

	@Override
	public int compareTo(Accion a) {
		return (int) (getValue() - a.getValue());
	}

}
