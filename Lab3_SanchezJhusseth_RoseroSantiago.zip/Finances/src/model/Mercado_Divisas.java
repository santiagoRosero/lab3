package model;

import java.util.ArrayList;

import red_black.Tree_RB;
import tree.ElementNullException;
import tree.ElementSameException;

public class Mercado_Divisas implements Comparable<Mercado_Divisas>{


	private ArrayList<Accion> accions;
    
    private Tree_RB<Accion> divisas;
    
    private String name;
    
	public Mercado_Divisas(){
       accions = new ArrayList<>();
       divisas = new Tree_RB<>();
       
       name = "";
    }
	
	
	public Tree_RB<Accion> getDivisas() {
		return divisas;
	}

	public void setDivisas(Tree_RB<Accion> divisas) {
		this.divisas = divisas;
	}

	
	
	public ArrayList<Accion> getAccions() {
		return accions;
	}

	public void setAccions(ArrayList<Accion> accions) {
		this.accions = accions;
	}
	
	public void insertAccion(Accion ac)throws ElementSameException {
		accions.add(ac);
		divisas.insert(ac);
	}
	
	
	public void deleteDivisa(Accion ac) throws ElementNullException{
		for (int i =0;i<accions.size();i++){
			if(accions.get(i).getFE().equals(ac.getFE())){		
				accions.remove(i);	
			}
		}
		divisas.delete(ac);
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void clear(){
		setAccions(new ArrayList<Accion>());
		divisas = new Tree_RB<>();
	}
	
	public Accion mayor(){
		return divisas.darMayor();
	}
	
    public Accion menor(){
		return divisas.darMinimo();
	}


	@Override
	public int compareTo(Mercado_Divisas md) {
		
		return name.compareTo(md.name);
	}

}
