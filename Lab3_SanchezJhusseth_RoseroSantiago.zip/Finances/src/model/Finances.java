package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import tree.ElementNullException;
import tree.ElementSameException;

public class Finances{
	
	private Mercado_Capital mc;
	private Mercado_Divisas md; 

 
	public Finances(){
		mc = new Mercado_Capital();
		md =  new Mercado_Divisas();
  
	}
  
 
	public ArrayList<Accion> getAccions() {	
		return md.getAccions();
	}
	
	public void reboot(){
		md.clear();
	}
	
	
	public Accion mayor(){
		return md.mayor();
	}
	
	public Accion menor(){
		return md.menor();
	}
	
	public void insert(Accion ac) throws ElementSameException{
		md.insertAccion(ac);
	}
  
  
  
	public void cargar(File f)throws IOException, ElementSameException{
		
		FileReader archivo = new FileReader(f);
		BufferedReader lector = new BufferedReader(archivo);
		
		String linea = lector.readLine();
		linea = lector.readLine();
		boolean termino = false;
		while (lector.ready() && !termino) {
			String[] datos = linea.split(",");
			
			String name = datos[0];
			double value = Double.parseDouble(datos[2]);
			
			char[] fe = datos[1].toCharArray();
			
			System.out.println(datos[1]);
			
			int day = Integer.parseInt(fe[2] +"" + fe[2]);
			int month = Integer.parseInt("" + fe[4]);
			int year = Integer.parseInt(fe[6] +"" + fe[7] + fe[8] +"" + fe[9]);
			
			
			
			int hour = Integer.parseInt(fe[11] +"" + fe[12]);
			int min = Integer.parseInt(fe[14] +"" + fe[15]);
			
			
			Fecha fecha = new Fecha(day,month,year,hour,min);
			Accion nuevo = new Accion(name, fecha, value); 
			md.insertAccion(nuevo);
			
			linea = lector.readLine();
			if (linea == "") {
				termino = true;
			}
		}
		lector.close();
	}
	
	
	public void delete(Accion nd) throws ElementNullException{
		md.deleteDivisa(nd);
	}
  
  
  
  
  
  

}
