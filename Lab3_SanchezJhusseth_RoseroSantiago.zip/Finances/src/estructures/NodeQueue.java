package estructures;

import java.io.Serializable; 
public class NodeQueue<T> implements Serializable
{
	private static final long serialVersionUID = 1L;
	
    private T element;

    private NodeQueue<T> nextNode;

    public NodeQueue( T pElement )
    {
        element = pElement;
        nextNode = null;
    }

    public T getElement( )
    {
        return element;
    }

    public NodeQueue<T> desconetFirts( )
    {
        NodeQueue<T> p = nextNode;
        nextNode = null;
        return p;
    }
    
    public NodeQueue<T> insertBefore( NodeQueue<T> node )
    {
        nextNode = node;
        return node;
    }

    public NodeQueue<T> getNext( )
    {
        return nextNode;
    }

    @Override
    public String toString( )
    {
        return element.toString( );
    }
}
