package estructures;

public class IteratorSimple<T> implements Iterator<T> 
{
	private static final long serialVersionUID = 1L;	

    private final static int NOTHING = -1;

    private T[] elems;

    private int posActual;

    private int nextPosFree;

    @SuppressWarnings("unchecked")
    public IteratorSimple( int tamanio )
    {
        elems = ( T[] )new Object[tamanio];
        nextPosFree = 0;
        posActual = NOTHING;
    }

    public boolean thereIsNext( )
    {
        return elems.length > 0 && ( posActual + 1 ) < nextPosFree;
    }

    public T getNext( )
    {
        return thereIsNext( ) ? elems[ ++posActual ] : null;
    }

    public T getAfter( )
    {
        return thereIsAfter( ) ? elems[ --posActual ] : null;
    }

    public boolean thereIsAfter( )
    {
        return elems.length > 0 && posActual > 0;
    }
    
    public void reboot( )
    {
        posActual = NOTHING;
    }

    public void add( T elem ) throws IteratorException
    {
        if( nextPosFree <= elems.length - 1 )
        {
            elems[ nextPosFree++ ] = elem;
        }
        else
            throw new IteratorException( "L�mite del iterador alcanzado" );
    }

    public void insert( T elem ) throws IteratorException
    {
        if( nextPosFree >= elems.length )
            throw new IteratorException( "L�mite del iterador alcanzado" );
        for( int i = nextPosFree; i > 0; i-- )
        {
            elems[ i ] = elems[ i - 1 ];
        }
        nextPosFree++;
        elems[ 0 ] = elem;
    }

    @Override
    public String toString( )
    {
        String resp = "[" + nextPosFree + "]:";
        for( int i = 0; i < nextPosFree; i++ )
        {
            resp += elems[ i ] + "-";
        }
        return resp;
    }

    public int getNextPosFree( )
    {
        return nextPosFree;
    }

    public int getPosActual( )
    {
        return posActual;
    }

    public int getLongitude( )
    {
        return elems.length;
    }
}
