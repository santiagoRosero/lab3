package estructures;

import java.io.Serializable; 

public interface Iterator<T> extends Serializable
{
    public boolean thereIsNext( );

    public T getNext( );

    public boolean thereIsAfter( );

    public T getAfter( );

    public void reboot( );
}
