package estructures;

import java.io.Serializable; 

public class ConcatenateQueue<T> implements Serializable
{
	private static final long serialVersionUID = 1L;
	
    protected NodeQueue<T> firts;

    protected NodeQueue<T> end;

    protected int numElems;

    public ConcatenateQueue( )
    {
        firts = null;
        end = null;
        numElems = 0;
    }

    public int getLongitude( )
    {
        return numElems;
    }

    public T takeElement( ) throws QueueEmptyException
    {
        if( firts == null )
            throw new QueueEmptyException( "No hay elementos en la cola" );
        else
        {
            NodeQueue<T> p = firts;
            firts = firts.desconetFirts( );
            if( firts == null )
                end = null;
            numElems--;
            return p.getElement( );
        }
    }

    public void insert( T element )
    {
        NodeQueue<T> node = new NodeQueue<T>( element );
        if( firts == null )
        {
            firts = node;
            end = node;
        }
        else
        {
            end = end.insertBefore( node );
        }
        numElems++;
    }
    
    public NodeQueue<T> getFirts( )
    {
        return firts;
    }

    public NodeQueue<T> getEnd( )
    {
        return end;
    }

    public boolean isEmpty( )
    {
        return firts == null;
    }
    
    @Override
    public String toString( )
    {
        String resp = "[" + numElems + "]:";
        for( NodeQueue<T> p = firts; p != null; p = p.getNext( ) )
        {
            resp += p.getElement( ).toString( ) + "->";
        }
        return resp;
    }

}
