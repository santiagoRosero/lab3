package estructures;

public class IteratorException extends Exception 
{
	private static final long serialVersionUID = 1L;	
    public IteratorException( String message )
    {
        super( message );
    }
}
